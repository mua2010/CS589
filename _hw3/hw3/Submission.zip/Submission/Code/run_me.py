from Template_SVM import main as svm_main
from Template_Ensembles import main as ensembles_main
from Template_Stacking import  main as stacking_main

svm_main()
ensembles_main()
stacking_main()