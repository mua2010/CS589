def SVD(A, s, k):
    # TODO: Calculate probabilities p_i
    n,m = A.shape

    # TODO: Construct S matrix of size s by m
    S = np.zeros((s,m))

    # TODO: Calculate SS^T


    # TODO: Compute SVD for SS^T


    # TODO: Construct H matrix of size m by k
    H = np.zeros((m,k))

    # Return matrix H and top-k singular values sigma

