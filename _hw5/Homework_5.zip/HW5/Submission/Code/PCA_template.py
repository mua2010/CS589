# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt

#Load data
X = np.load('Data/X_train.npy')
Y = np.load('Data/y_train.npy')
#%% Plotting mean of the whole dataset

#%% Plotting each digit

#%% Center the data (subtract the mean)

#%% Calculate Covariate Matrix

#%% Calculate eigen values and vectors

#%% Plot eigen values

#%% Plot 5 first eigen vectors

#%% Project to two first bases

#%% Plotting the projected data as scatter plot
