import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.neighbors import BallTree
from sklearn.model_selection import KFold


def f1_score(y_true, y_pred):
    """
    Function for calculating the F1 score

    Params
    ------
    y_true  : the true labels shaped (N, C), 
              N is the number of datapoints
              C is the number of classes
    y_pred  : the predicted labels, same shape
              as y_true

    Return
    ------
    score   : the F1 score, shaped (N,)

    """
    pass




class KNN(object):
    """
    The KNN classifier
    """
    def __init__(self, n_neighbors):
        self.K = n_neighbors

    def getKNeighbors(self, x_instance):
        """
        Locating the K nearest neighbors of 
        the instance and return
        """
        pass

    def fit(self, x_train, y_train):
        """
        Fitting the KNN classifier

        Hint:   Build a tree to get neighbors 
                faster at test time
        """
        pass

    def predict(self, x_test):
        """
        Predicting the test data
        Hint:   Get the K-Neighbors, then generate
                predictions using the labels of the
                neighbors
        """
        pass



def main():
    # Example running the class KNN
    knn = KNN(n_neighbors=5)
    knn.fit(x_train, y_train)
    y_pred = knn.predict(x_test)
    score = f1_score(y_test, y_pred)

    ########################################
    # Simple Guide on KFold
    ########################################
    kf = KFold(n_splits=5)
    kf.get_n_splits(X)

    for i, (train_index, test_index) in enumerate(kf.split(X)):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]








