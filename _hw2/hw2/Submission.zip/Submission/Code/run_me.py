from NB_Template import main as nb_main
from LR_template import main as lr_main
from best_model import  main as bm_main

nb_main()
lr_main()
bm_main()