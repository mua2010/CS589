from Q1_Template import main as q1_main
from Q2_Template import main as q2_main

q1_main()
q2_main()
